# -*- coding: utf-8 -*-
"""
-------------------------------------------------
# @Project  :statlearning-sjtu-2021
# @File     :model
# @Date     :2021/12/7 20:53
# @Author   :Xinqi Chen
# @Software :PyCharm
-------------------------------------------------
"""
import argparse

import torch
import torch.nn as nn
import numpy as np
import torch.nn.functional as F
from torch.utils.data import Dataset
import math
from config import arg_list, data_len, data_width
from utils import split_last, merge_last


# 制作数据集
class PrepareDataset(Dataset):
    def __init__(self, data, label):
        # super().__init__()
        self.data = data
        self.label = label

    def __getitem__(self, index):
        instance = self.data[index]
        return torch.from_numpy(instance).float(), torch.from_numpy(np.array(self.label[index])).long()

    def __len__(self):
        return len(self.data)


# 训练模型主体
def choose_model(arg):
    if arg not in arg_list:
        raise Exception("Model not in list!")
    if arg == 'rf':
        from sklearn.ensemble import RandomForestClassifier
        model = RandomForestClassifier(n_estimators=120)
        # model.fit(trainX, trainY, train_wt)
    elif arg == 'svm':
        from sklearn import svm
        model = svm.SVC(C=3)
        # model = svm.SVC(C=3, kernel='rbf', decision_function_shape='ovr')
        # model.fit(train_data, train_label.ravel())  # ravel函数在降维时默认是行序优先
    elif arg == 'k-neighbor':
        from sklearn.neighbors import KNeighborsClassifier
        model = KNeighborsClassifier(n_neighbors=10)
    elif arg == 'mlp':
        model = MLP(in_channel=100, label_num=20)
    else:
        # Bert参数
        parser1 = argparse.ArgumentParser(description='Bert')
        parser1.add_argument('--n_heads', type=int, default=4)
        parser1.add_argument('--n_layer', type=int, default=4)
        parser1.add_argument('--hidden', type=int, default=72)
        parser1.add_argument('--hidden_ff', type=int, default=144)
        parser1.add_argument('--seq_len', type=int, default=100)
        parser1.add_argument('--feature_num', type=int, default=15)
        parser1.add_argument('--emb_norm', type=bool, default=True)
        cfg = parser1.parse_args()
        # GRU参数
        parser2 = argparse.ArgumentParser(description='GRU')
        parser2.add_argument('--seq_len', type=int, default=100)
        parser2.add_argument('--input', type=int, default=15)
        parser2.add_argument('--num_rnn', type=int, default=2)
        parser2.add_argument('--num_layers', default=[2, 1])
        parser2.add_argument('--rnn_io', default=[[6, 30], [30, 40]])
        parser2.add_argument('--num_linear', type=int, default=1)
        parser2.add_argument('--linear_io', type=int, default=[[40, 20]])
        parser2.add_argument('--activ', type=bool, default=False)
        parser2.add_argument('--dropout', type=bool, default=True)
        mfg = parser2.parse_args()
        # model = Transformer(cfg, mfg)
    return model


class MLP(nn.Module):
    def __init__(self, in_channel, label_num, dropout=0.8):
        super(MLP, self).__init__()
        self.in_channel = in_channel
        self.label_num = label_num
        self.layer1 = nn.Linear(in_channel, 128)
        self.bn1 = nn.BatchNorm1d(data_len)
        self.relu1 = nn.ReLU()
        self.layer2 = nn.Linear(128, 64)
        self.relu2 = nn.ReLU()
        self.bn2 = nn.BatchNorm1d(data_len)
        self.layer3 = nn.Linear(64*data_len, label_num)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x):
        x = self.bn1(self.relu1(self.layer1(x)))
        x = self.bn2(self.relu2(self.layer2(x)))
        x = x.flatten(start_dim=1)
        x = self.dropout(x)
        x = self.layer3(x)
        return x
